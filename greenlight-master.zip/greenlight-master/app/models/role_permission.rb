# frozen_string_literal: true

class RolePermission < ApplicationRecord
  belongs_to :role
end
